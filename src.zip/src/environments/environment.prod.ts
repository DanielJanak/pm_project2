export const environment = {
  production: true,
  api:{
    //key:'',  //sem napíšu klíč, ten unikátní šílenej dlouhej (možná ho na tuhle shitnou API nepotřebuju)
    Url:'https://dog.ceo'   //sem zase url apiny kterou jsem si zvolil
  }
};
