import { Component, Inject, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LoadingController } from '@ionic/angular';
import { Observable } from 'rxjs';
import { ApiService } from '../service/api/api.service';

@Component({
  selector: 'app-tab1',
  templateUrl: 'tab1.page.html',
  styleUrls: ['tab1.page.scss']
})
export class Tab1Page implements OnInit {
  obrazky: string[] = [];  //obrázky využívám pro příjem URL random obrázku

  pole: string | null = 'null';  //do pole ukládám URL obrázku který se potom zobrazí na main page

  odrudy: string = 'null'; //string pro celý request odrůd psů od API

  odrudypsupole_tab1 = this.ApiService.odrudypsupole;  //převzaté pole odrůd psů z ApiService

  constructor(private ApiService: ApiService, private loadingCtrl: LoadingController) {}

  public getData(key: string) {  //getData z LocalStorage
    return localStorage.getItem(key);
  }

  ngOnInit() {  //metoda při načtení tab1 page, kterou taky používám pro generování random obrázku
    this.loadPicture();
  }

  async loadPicture() {  //loading dialog uprostřed obrazovky
    const loading = await this.loadingCtrl.create({
      message: 'Loading...',
      spinner: 'bubbles',
    });
    await loading.present();

    this.ApiService.getRandomPhoto().subscribe(res => {  //do proměnné res subscribnu return z metody getRandomPhoto
      loading.dismiss();
      this.obrazky.push(...res.message);
      //console.log(res);  //res = sucess + message
      if (this.obrazky != null) {
        this.obrazky = [];
        this.obrazky.push(...res.message);
        this.pole = res.message;  //zde si do pole uložím hodnotu message kterou pak používám v html pro zobrazení obrázku
      }
    });
  }


  ngOnFavourite() {  // metoda pro přidání itemu do favourite
    this.saveFavourite();
  }

  async saveFavourite() {
    const loading = await this.loadingCtrl.create({
      message: 'Loading...',
      spinner: 'bubbles',
    });
    await loading.present();
    loading.dismiss();

    if (this.pole != null) {
      localStorage.setItem(this.pole, this.pole);  //setuju item do localstorage
      this.pole = this.getData(this.pole);
      //console.log(this.pole);  //pouze kontrolní výpis hodnoty která se zrovna zapsala do localstorage
    }
  }


  ngOnVyber() {  //metoda která se zavolá při stisknutí tlačítka výběr (otevře modal)
    this.loadVyberOdrud2();
  }

  async loadVyberOdrud2() {
    const loading = await this.loadingCtrl.create({
      message: 'Loading...',
      spinner: 'bubbles',
    });
    await loading.present();

    loading.dismiss();
    
    await this.ApiService.getSpecificOdruda(3);  //97 je max hodnota kterou tam lze zadat, poté už je to mimo pole (undefined) //tohle volá funkci z api service
    this.odrudypsupole_tab1 = this.ApiService.odrudypsupole; //zde změním hodnotu mé pomocné tabulky
  }

  ngOnOdruda(c: string) {  //při stisknutí itemu v modalu se zavolá a předá tato hodnota url obrázku, která se pak zobrazí na main page
    this.ApiService.getReturnSpecifiedBreed(c).subscribe(res => {
      console.log(res.message);
      this.pole = res.message;  //hodnota this.pole se přepíše aktuálně příchozí URL a změní se tak na main page
    });
  }
}