/* export interface Promena {  //toto mělo být interface na zpracování všech breedů
      breed: string;
      subbreed: string[];
      }; */


/* export class Odrudy {
      seznam: string[] = ["jmeno", "druhyjmeno"];
} */