import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { map, Observable } from "rxjs";

import { environment } from 'src/environments/environment';
import { Tab1Page } from "src/app/tab1/tab1.page";
import { SelectMultipleControlValueAccessor } from "@angular/forms";
import { waitForAsync } from "@angular/core/testing";


export interface ApiResult {
    status: string;
    message: string;
}

@Injectable({
    providedIn: "root"
})

export class ApiService {
    temp: string = 'null';  //pomocná proměnná string kterou využívám pro vyrobení pole stringů odrůd psů
    odrudypsupole: string[] = [];  //do tohoto pole ukládám všechny odrůdy psů

    vybranarasa: string = 'null';

    constructor(private http: HttpClient) { } //toto je tam proto aby jsme mohli extractit věci z API

    getRandomPhoto(): Observable<ApiResult> {  //získá random photo z API
        return this.http.get<ApiResult>(
            `${environment.api.Url}/api/breeds/image/random`);  //Alt + 96 -> ty speciální uvozovky
    }


    getOdrudyPsu(): Observable<ApiResult> {   //získá zpátky z API všechny odrůdy psů v RAW formě
        return this.http.get<ApiResult>(`${environment.api.Url}/api/breeds/list/all`);
    }

    getOdrudyList() {  //Tato funkce využije getOdrudyPsu a zpracuje výsledek do odrudypsupole[] kde bude celý seznam všech odrůd v použitelné formě
        this.getOdrudyPsu().subscribe(res => {

            this.temp = JSON.stringify(res.message);

            this.odrudypsupole = [];
            var i = 0;
            while (i == 0) {  //v tomto whilu se do odrudypsupole uloží všechny odrudy psu

                if (this.temp.indexOf('\}') == 0) {  //tímto ifem ukončím while protože dojdu na konec stringu
                    i = 1;
                }

                else if (this.temp.indexOf('\[') == 0) {  //tímto narazím na tuhle závorku, jejíž obsah chci odstranit
                    this.temp = this.temp.substring(1);  //tímto odstraním jeden znak
                    var x = 0;
                    while (x == 0) {
                        if (this.temp.charAt(0) == '\]') {
                            this.temp = this.temp.substring(1);
                            x = 1;
                        }

                        else if (this.temp.charAt(0) != '\]') {
                            this.temp = this.temp.substring(1);
                        }
                    }
                }

                else if (this.temp.indexOf('\"') == 0) {
                    this.temp = this.temp.substring(1);
                    var temporary = this.temp.indexOf('\"');
                    this.odrudypsupole.push(this.temp.slice(0, temporary));  //tento řádek vkládá do odrudypsupole
                    this.temp = this.temp.slice(temporary + 1);
                }

                else {
                    this.temp = this.temp.substring(1);
                }
            }
        });
    }

    async getSpecificOdruda(a: number) {  //tahleta metoda je tam asi jen kvůli inicializaci
        this.getOdrudyPsu();
        this.getOdrudyList();
        const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));
        await sleep(300);  //se sleepem je to funkční... Nestihne se to zpracovat předtím než to chci vypsat....
        this.vybranarasa = this.odrudypsupole[a];
    }

    getReturnSpecifiedBreed(b: string): Observable<ApiResult> {  //https://dog.ceo/api/breed/hound/images
        return this.http.get<ApiResult>(
            `${environment.api.Url}/api/breed/` + b + `/images/random`);  //returne obrázek rasy psa kterou jsme vybrali v modalu
    }
}